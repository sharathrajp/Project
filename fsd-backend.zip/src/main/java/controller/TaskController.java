package controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import model.Project;
import model.Task;
import model.Users;
import service.TaskService;

@RestController
@CrossOrigin
public class TaskController {
	@Autowired
	private TaskService taskService;

	@GetMapping("/tasks")
	public ResponseEntity<List<Task>> getAllTasks() {
		try {
			List<Task> taskList = taskService.getAllTasks();
			return new ResponseEntity<List<Task>>(taskList, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<List<Task>>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("/task/{id}")
	public ResponseEntity<Task> getAllTasks(@PathVariable Long id) {
		try {
			Task task = taskService.findTaskById(id);
			return new ResponseEntity<Task>(task, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<Task>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@DeleteMapping("/task/{id}")
	public ResponseEntity<Boolean> deleteTask(@PathVariable Long id) {
		try {
			Boolean success = taskService.deleteTask(id);
			return new ResponseEntity<Boolean>(success, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<Boolean>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping("/task/save")
	public @ResponseBody ResponseEntity<Long> saveTask(@RequestBody Task task) {
		try {
			Long savedTask = taskService.saveTask(task);
			return new ResponseEntity<Long>(savedTask, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<Long>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@PostMapping("/task/update")
	public @ResponseBody ResponseEntity<Boolean> updateTask(@RequestBody Task task) {
		try {
			boolean updatedTask = taskService.updateTask(task);
			return new ResponseEntity<Boolean>(updatedTask, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<Boolean>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@PostMapping("project/save")
	public @ResponseBody ResponseEntity<Long> saveProject(@RequestBody Project project) {
		try {
			Long savedProject = taskService.saveProject(project);
			return new ResponseEntity<Long>(savedProject, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<Long>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@PostMapping("project/update")
	public @ResponseBody ResponseEntity<Long> updateProject(@RequestBody Project project) {
		try {
			Long savedProject = taskService.saveProject(project);
			return new ResponseEntity<Long>(savedProject, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<Long>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@PostMapping("user/save")
	public @ResponseBody ResponseEntity<Boolean> saveUser(@RequestBody Users user) {
		try {
			boolean savedUser = taskService.saveUser(user);
			return new ResponseEntity<Boolean>(savedUser, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<Boolean>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@PostMapping("user/update")
	public @ResponseBody ResponseEntity<Boolean> updateUser(@RequestBody Users user) {
		try {
			boolean savedUser = taskService.updateUser(user);
			return new ResponseEntity<Boolean>(savedUser, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<Boolean>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("user/task/assign/{userId}/{taskId}")
	public @ResponseBody ResponseEntity<Boolean> assignUserTask(@PathVariable Long userId, @PathVariable Long taskId) {
		try {
			boolean result = taskService.assignTaskToUser(userId, taskId);
			return new ResponseEntity<Boolean>(result, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<Boolean>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@GetMapping("user/project/assign/{userId}/{projectId}")
	public @ResponseBody ResponseEntity<Boolean> assignUserProject(@PathVariable Long userId, @PathVariable Long projectId) {
		try {
			boolean result = taskService.assignProjectToUser(userId, projectId);
			return new ResponseEntity<Boolean>(result, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<Boolean>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@GetMapping("users")
	public @ResponseBody ResponseEntity<List<Users>> getUsers() {
		try {
			List<Users> result = taskService.getUsers();
			return new ResponseEntity<List<Users>>(result, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<List<Users>>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("projects")
	public @ResponseBody ResponseEntity<List<Project>> getProjects() {
		try {
			List<Project> result = taskService.getProjects();
			return new ResponseEntity<List<Project>>(result, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<List<Project>>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("user/delete/{userId}")
	public @ResponseBody ResponseEntity<Boolean> deleteUser(@PathVariable Long userId) {
		boolean result = false;
		try {
			result = taskService.deleteUser(userId);
			return new ResponseEntity<Boolean>(result, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<Boolean>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
