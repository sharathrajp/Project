export class Project {
  public project: string;
  public projectId: number;
  public startDate: Date;
  public endDate: Date;
  public priority: number;
  constructor() {
    this.project = '';
    this.projectId = undefined;
    this.startDate = undefined;
    this.endDate = undefined;
    this.priority = undefined;
  }
}
