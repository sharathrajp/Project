import { Project } from './project.dto';
import { ParentTask } from './parent-task.dto';

export class Task {
  public taskId: number;
  public task: string;
  public startDate: Date;
  public endDate: Date;
  public priority: number;
  public parentTask: ParentTask;
  public status: string;
  public project: Project;

  constructor() {
    this.taskId = undefined;
    this.task = undefined;
    this.startDate = undefined;
    this.endDate = undefined;
    this.priority = undefined;
    this.parentTask = new ParentTask();
    this.status = undefined;
    this.project = new Project();
  }
}
