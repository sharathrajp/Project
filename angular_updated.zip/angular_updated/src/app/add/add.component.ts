import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Task } from '../dto/task.dto';
import { TaskService } from '../service/task.service';
import { User } from '../dto/user.dto';
import { Project } from '../dto/project.dto';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  public task: Task;
  public userSearchField: string;
  public userList: [User];
  public userSearchList = [];
  public selectedUserId: number;
  public projectSearchField: string;
  public projectList: [Project];
  public projectSearchList = [];
  public selectedProjectId: number;

  constructor(private httpClient: HttpClient, private taskService: TaskService) { }

  ngOnInit() {
    this.initialize();
  }

  private initialize() {
    this.task = new Task();
    this.getUsers();
    this.getProjects();

  }

  private getUsers() {
    this.taskService.getUsers()
      .then((data: [User]) => {
        this.userList = data;
      })
      .catch(error => alert('Error in fetching users!'));
  }

  public searchUsers() {
    const searchResults = this.userList.filter(user => {
      if (user.firstName.toLocaleLowerCase().search(this.userSearchField.toLocaleLowerCase()) !== -1 ||
      user.lastName.toLocaleLowerCase().search(this.userSearchField.toLocaleLowerCase()) !== -1 ||
      (user.firstName + ' ' + user.lastName).toLocaleLowerCase().search(this.userSearchField.toLocaleLowerCase()) !== -1) {
        return true;
      }
      return false;
    });
    if (this.userSearchList) {
      this.userSearchList.splice(0, this.userSearchList.length);
    }
    for (const searchResult of searchResults) {
      const user: any = new Object();
      user.code = searchResult.userId;
      user.label = searchResult.firstName + ' ' + searchResult.lastName;
      this.userSearchList.push(user);
    }
  }

  public clearUserSearch() {
    if (this.userSearchList) {
      this.userSearchList.splice(0, this.userSearchList.length);
    }
  }

  public selectUser(user: any) {
    this.selectedUserId = user.code;
    this.clearUserSearch();
    this.userSearchField = user.label;
  }

  private getProjects() {
    this.taskService
      .getProjects()
      .then((data: [Project]) => {
        this.projectList = data;
      })
      .catch(error => alert('Error in fetching projects!'));
  }

  public searchProjects() {
    const searchResults = this.projectList.filter((project: Project) => {
      console.log(project.project);
      if (project.project.toLowerCase().search(this.projectSearchField.toLowerCase()) !== -1) {
        return true;
      }
      return false;
    });
    if (this.projectSearchList) {
      this.projectSearchList.splice(0, this.projectSearchList.length);
    }
    for (const searchResult of searchResults) {
      const user: any = new Object();
      user.code = searchResult.projectId;
      user.label = searchResult.project;
      this.projectSearchList.push(user);
    }
  }

  public clearProjectSearch() {
    if (this.projectSearchList) {
      this.projectSearchList.splice(0, this.projectSearchList.length);
    }
  }

  public selectProject(project: any) {
    this.task.project.projectId = project.code;
    this.clearUserSearch();
    this.projectSearchField = project.label;
  }

  public saveTask() {
    this.taskService.saveTask(this.task).then( taskId => {
      this.taskService.assignTaskToUser(taskId, this.selectedUserId).then (data => {
        alert('Task saved!');
      }).catch(error => {
        alert('Fail to assign task to user!');
      });
    }).catch(error => {
      alert('Fail to create task!');
    });
  }

}
