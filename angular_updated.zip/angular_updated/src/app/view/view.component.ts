import { Component, OnInit } from '@angular/core';
import { Task } from '../dto/task.dto';
import { TaskService } from '../service/task.service';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {

  public taskList: any;
  public taskListCopy: any;
  public taskSearchField: string;

  constructor(private taskService: TaskService) { }

  ngOnInit() {
    this.initialize();
  }

  private getTasks() {
    this.taskService.getTasks().then(tasks => {
      this.taskList = tasks;
      this.taskListCopy = JSON.parse(JSON.stringify(tasks));
    });
  }

  private initialize() {
    this.getTasks();
  }

  public searchTask() {
    this.taskList = this.taskListCopy.filter(task => {
      if (task.task.toLocaleLowerCase().search(this.taskSearchField.toLocaleLowerCase()) !== -1) {
        return true;
      }
      return false;
    });
  }

  public clearTaskSearch() {
    if (!this.taskSearchField) {
      this.taskList = JSON.parse(JSON.stringify(this.taskListCopy));

    }
  }

  public sortTasks(column: any, type: any) {
    this.taskList.sort((task1, task2) => {
      if (type === 'date') {
        return new Date(task1[column]).getTime() - new Date(task2[column]).getTime();
      } else if (type === 'number') {
        return Number(task1[column]) - Number(task2[column]);
      } else if (type === 'string') {
        return String(task1[column]).localeCompare(String(task2[column]));
      }
    });
  }

}
