import { Component, OnInit } from '@angular/core';
import { ProjectService } from '../service/project.service';
import { Project } from '../dto/project.dto';
import { User } from '../dto/user.dto';

@Component({
  selector: 'app-project',
  templateUrl: './project.component.html',
  styleUrls: ['./project.component.css']
})
export class ProjectComponent implements OnInit {
  public projectList: any;
  public projectListCopy: [Project];
  public project: Project;
  public setStartAndEnd: boolean;
  public managerField: string;
  public selectedManagerId: number;
  public userList: [User];
  public userSearchList: any;
  public projectSearchField: string;

  constructor(private projectService: ProjectService) { }

  ngOnInit() {
    this.initialize();
  }

  private getProjects() {
    this.projectService
      .getProjects()
      .then((data: [Project]) => {
        this.projectList = data;
        this.projectListCopy = JSON.parse(JSON.stringify(data));
      })
      .catch(error => alert('Error in fetching projects!'));
  }

  private getUsers() {
    this.projectService.getUsers()
      .then((data: [User]) => {
        this.userList = data;
      })
      .catch(error => alert('Error in fetching users!'));
  }

  public searchUsers() {
    const searchResults = this.userList.filter(user => {
      if (user.firstName.toLocaleLowerCase().search(this.managerField.toLocaleLowerCase()) !== -1 ||
      user.lastName.toLocaleLowerCase().search(this.managerField.toLocaleLowerCase()) !== -1 ||
      (user.firstName + ' ' + user.lastName).toLocaleLowerCase().search(this.managerField.toLocaleLowerCase()) !== -1) {
        return true;
      }
      return false;
    });
    if (this.userSearchList) {
      this.userSearchList.splice(0, this.userSearchList.length);
    }
    for (const searchResult of searchResults) {
      const user: any = new Object();
      user.code = searchResult.userId;
      user.label = searchResult.firstName + ' ' + searchResult.lastName;
      this.userSearchList.push(user);
    }
  }

  public clearUserSearch() {
    this.userSearchList.splice(0, this.userSearchList.length);
  }

  public selectUser(user: any) {
    this.selectedManagerId = user.code;
    this.clearUserSearch();
    this.managerField = user.label;
  }

  public saveProject() {
    this.projectService.saveProject(this.project).then(data => {
      this.projectService.assignProjectToUser(this.selectedManagerId, data).then(data2 => {
        alert('Project saved!');
        this.initialize();
      }).catch(error => { alert('Failed to assign manager!'); });
    }).catch(error => { alert('Failed to save project!'); });
  }

  public searchProject() {
    this.projectList = this.projectList.filter((project => {
      if (String(project.project).toLocaleLowerCase().search(this.projectSearchField.toLocaleLowerCase()) !== -1) {
        return true;
      }
      return false;
    }));
  }

  public clearSearchProject() {
    if (!this.projectSearchField) {
      this.projectList = JSON.parse(JSON.stringify(this.projectListCopy));
    }
  }

 

  public initialize() {
    this.getProjects();
    this.getUsers();
    this.project = new Project();
    this.managerField = '';
    this.setStartAndEnd = false;
    this.userSearchList = [];
  }
}
