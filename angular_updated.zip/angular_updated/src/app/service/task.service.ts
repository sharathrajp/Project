import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Task } from '../dto/task.dto';

@Injectable()
export class TaskService {
  constructor(private httpClient: HttpClient) {

  }
  private url = 'http://localhost:8082/';

  public getTasks() {
    const api = this.url + 'tasks';
    return this.httpClient.get(api).toPromise();
  }

  public getProjects() {
    const api = this.url + 'projects';
    return this.httpClient.get(api).toPromise();
  }

  public getUsers() {
    const api = this.url + 'users';
    return this.httpClient.get(api).toPromise();
  }

  public saveTask(task: Task) {
    const api = this.url + 'task/save';
    delete task.taskId;
    delete task.status;
    return this.httpClient.post(api, task).toPromise();
  }

  public assignTaskToUser(taskId: any, projectId: any) {
    const api = this.url + 'user/task/assign/' + taskId + '/' + projectId;
    return this.httpClient.get(api).toPromise();
  }
}
