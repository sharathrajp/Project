import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddComponent } from './add/add.component';
import { ViewComponent } from './view/view.component';
import { UserComponent } from './user/user.component';
import { ProjectComponent } from './project/project.component';
import { ProjectService } from './service/project.service';
import { UserService } from './service/user.service';
import { TaskService } from './service/task.service';

@NgModule({
  declarations: [
    AppComponent,
    AddComponent,
    ViewComponent,
    UserComponent,
    ProjectComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [ProjectService, UserService, TaskService],
  bootstrap: [AppComponent]
})
export class AppModule { }
