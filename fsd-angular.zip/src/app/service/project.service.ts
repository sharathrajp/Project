import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Project } from '../dto/project.dto';

@Injectable()
export class ProjectService {
  private url = 'http://localhost:8082/';
  constructor(private httpClient: HttpClient) {
  }

  public saveProject(project: Project) {
    const api = this.url + 'project/save';
    delete project.projectId;
    return this.httpClient.post(api, project).toPromise();
  }

  public updateProject(project: Project) {
    const api = this.url + 'project/update';
    return this.httpClient.post(api, project).toPromise();
  }

  public getProjects() {
    const api = this.url + 'projects';
    return this.httpClient.get(api).toPromise();
  }

  public getUsers() {
    const api = this.url + 'users';
    return this.httpClient.get(api).toPromise();
  }

  public assignProjectToUser(userId: any, projectId: any) {
    const api = this.url + 'user/project/assign/' + userId + '/' + projectId;
    return this.httpClient.get(api).toPromise();
  }
}
