import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../dto/user.dto';

@Injectable()
export class UserService {
  constructor(private httpClient: HttpClient) {

  }
  private url = 'http://localhost:8082/';
  public getUsers() {
    const api = this.url + 'users';
    return this.httpClient.get(api).toPromise();
  }

  public saveUser(user: User) {
    const api = this.url + 'user/save';
    delete user.userId;
    delete user.project;
    delete user.task;
    return this.httpClient.post(api, user).toPromise();
  }

  public updateUser(user: User) {
    const api = this.url + 'user/update';
    return this.httpClient.post(api, user).toPromise();
  }

  public deleteUser(userId: any) {
    const api = this.url + 'user/delete/' + userId;
    return this.httpClient.get(api).toPromise();
  }
}
