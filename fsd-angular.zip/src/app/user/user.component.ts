import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../service/user.service';
import { User } from '../dto/user.dto';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  public edit = false;
  public user: User;
  public userList: any;
  public userListCopy: any;
  public userSearchField: string;

  constructor(private userService: UserService, private route: ActivatedRoute, private router: Router) { }

  ngOnInit() {
    this.initialize();
    this.router.events.subscribe(routerData => {
      this.initialize();
    });
  }

  private getUsers() {
    this.userService.getUsers()
      .then((data: [User]) => {
        this.userList = data;
        this.userListCopy = JSON.parse(JSON.stringify(data));
      })
      .catch(error => alert('Error in fetching users!'));
  }


  public saveUser() {
    this.userService.saveUser(this.user).then(data => {
      alert('User saved!');
      this.initialize();
    }).catch(error => { alert('An error occured!'); });
  }

  public updateUser() {
    this.userService.updateUser(this.user).then(data => {
      alert('User updated!');
      this.initialize();
    }).catch(error => { alert('An error occured!'); });
  }

  public deleteUser(userId: any) {
    this.userService.deleteUser(userId).then(data => {
      alert('User deleted!');
      this.initialize();
      }).catch(error => {
        alert('User delete failed!');
    });
  }

  private initialize() {
    this.user = new User();
    this.getUsers();
    this.edit = false;
  }

  public searchUser() {
    this.userList = this.userListCopy.filter(user => {
      if (user.firstName.toLocaleLowerCase().search(this.userSearchField.toLocaleLowerCase()) !== -1 ||
        user.lastName.toLocaleLowerCase().search(this.userSearchField.toLocaleLowerCase()) !== -1 ||
        (user.firstName + ' ' + user.lastName).toLocaleLowerCase().search(this.userSearchField.toLocaleLowerCase()) !== -1 ||
        String(user.employeeId).toLocaleLowerCase().search(this.userSearchField.toLocaleLowerCase()) !== -1) {
        return true;
      }
      return false;
    });
  }

  public clearUserSearch() {
    if (!this.userSearchField) {
      this.userList = JSON.parse(JSON.stringify(this.userListCopy));

    }
  }

  public sortUsers(column: any, type: any) {
    this.userList.sort((user1, user2) => {
      if (type === 'date') {
        return new Date(user1[column]).getTime() - new Date(user2[column]).getTime();
      } else if (type === 'number') {
        return Number(user1[column]) - Number(user2[column]);
      } else if (type === 'string') {
        return String(user1[column]).localeCompare(String(user2[column]));
      }
    });
  }

  public editUser(user: User) {
    this.edit = true;
    this.user = JSON.parse(JSON.stringify(user));
  }

  public cancelUpdate() {
    this.edit = false;
    this.initialize();
  }

}
