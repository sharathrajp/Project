export class ParentTask {
  public parentId: number;
  public parentTask: string;

  constructor() {
    this.parentId = undefined;
    this.parentTask = undefined;
  }
}
