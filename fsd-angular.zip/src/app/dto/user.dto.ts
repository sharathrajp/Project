import { Project } from './project.dto';
import { Task } from './task.dto';

export class User {
  public userId: number;
  public firstName: string;
  public lastName: string;
  public employeeId: string;
  public project: Project;
  public task: Task;

  constructor() {
    this.userId = undefined;
    this.firstName = undefined;
    this.lastName = undefined;
    this.employeeId = undefined;
    this.project = new Project();
    this.task = new Task();
  }
}
