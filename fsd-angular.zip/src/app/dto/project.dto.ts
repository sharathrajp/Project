export class Project {
  public project: string;
  public projectId: number;
  public startDate: any;
  public endDate: any;
  public priority: number;
  constructor() {
    this.project = '';
    this.projectId = undefined;
    this.startDate = undefined;
    this.endDate = undefined;
    this.priority = undefined;
  }
}
