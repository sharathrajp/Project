import { Component, OnInit } from '@angular/core';
import { ProjectService } from '../service/project.service';
import { Project } from '../dto/project.dto';
import { User } from '../dto/user.dto';

@Component({
  selector: 'app-project',
  templateUrl: './project.component.html',
  styleUrls: ['./project.component.css']
})
export class ProjectComponent implements OnInit {
  public projectList: any;
  public projectListCopy: [Project];
  public project: Project;
  public setStartAndEnd: boolean;
  public managerField: string;
  public selectedManagerId: number;
  public userList: [User];
  public userSearchList: any;
  public projectSearchField: string;
  public edit: boolean;

  constructor(private projectService: ProjectService) { }

  ngOnInit() {
    this.initialize();
  }

  private getProjects() {
    this.projectService
      .getProjects()
      .then((data: [Project]) => {
        this.projectList = data;
        this.projectListCopy = JSON.parse(JSON.stringify(data));
      })
      .catch(error => alert('Error in fetching projects!'));
  }

  private getUsers() {
    this.projectService.getUsers()
      .then((data: [User]) => {
        this.userList = data;
      })
      .catch(error => alert('Error in fetching users!'));
  }

  public searchUsers() {
    const searchResults = this.userList.filter(user => {
      if (user.firstName.toLocaleLowerCase().search(this.managerField.toLocaleLowerCase()) !== -1 ||
        user.lastName.toLocaleLowerCase().search(this.managerField.toLocaleLowerCase()) !== -1 ||
        (user.firstName + ' ' + user.lastName).toLocaleLowerCase().search(this.managerField.toLocaleLowerCase()) !== -1) {
        return true;
      }
      return false;
    });
    if (this.userSearchList) {
      this.userSearchList.splice(0, this.userSearchList.length);
    }
    for (const searchResult of searchResults) {
      const user: any = new Object();
      user.code = searchResult.userId;
      user.label = searchResult.firstName + ' ' + searchResult.lastName;
      this.userSearchList.push(user);
    }
  }

  public clearUserSearch() {
    this.userSearchList.splice(0, this.userSearchList.length);
  }

  public selectUser(user: any) {
    this.selectedManagerId = user.code;
    this.clearUserSearch();
    this.managerField = user.label;
  }

  public saveProject() {
    this.projectService.saveProject(this.project).then(data => {
      this.projectService.assignProjectToUser(this.selectedManagerId, data).then(data2 => {
        alert('Project saved!');
        this.initialize();
      }).catch(error => { alert('Failed to assign manager!'); });
    }).catch(error => { alert('Failed to save project!'); });
  }

  public searchProject() {
    this.projectList = this.projectList.filter((project => {
      if (String(project.project).toLocaleLowerCase().search(this.projectSearchField.toLocaleLowerCase()) !== -1) {
        return true;
      }
      return false;
    }));
  }

  public clearSearchProject() {
    if (!this.projectSearchField) {
      this.projectList = JSON.parse(JSON.stringify(this.projectListCopy));
    }
  }



  public initialize() {
    this.getProjects();
    this.getUsers();
    this.project = new Project();
    this.managerField = '';
    this.setStartAndEnd = false;
    this.userSearchList = [];
    this.edit = false;
  }


  public sortProjects(column: any, type: any) {
    this.projectList.sort((proj1, proj2) => {
      if (type === 'date') {
        return new Date(proj1[column]).getTime() - new Date(proj2[column]).getTime();
      } else if (type === 'number') {
        return Number(proj1[column]) - Number(proj2[column]);
      } else if (type === 'string') {
        return String(proj1[column]).localeCompare(String(proj2[column]));
      }
    });
  }

  public update(project: Project) {
    this.edit = true;
    this.project = JSON.parse(JSON.stringify(project));
    const selectedManager = this.userList.find(element => {
      if (element.project && element.project.projectId && this.project.projectId) {
        return String(element.project.projectId) === String(this.project.projectId);
      }
      return false;
    });
    if (selectedManager) {
      this.selectedManagerId = selectedManager.userId;
      this.managerField = selectedManager.firstName + ' ' + selectedManager.lastName;
    } else {
      this.selectedManagerId = undefined;
      this.managerField = undefined;
    }
  }

  public updateProject() {
    this.projectService.updateProject(this.project).then(data => {
      this.projectService.assignProjectToUser(this.selectedManagerId, data).then(data2 => {
        alert('Project updated!');
        this.initialize();
      }).catch(error => { alert('Failed to update manager!'); });
    }).catch(error => { alert('Failed to update project!'); });
  }

  public cancelUpdate() {
    this.initialize();
  }

  public setStartEndDate() {
    if (this.setStartAndEnd) {
      this.project.startDate = this.formatDate(new Date());
      const endDate: Date = new Date();
      endDate.setFullYear(endDate.getFullYear() + 1);
      this.project.endDate = this.formatDate(endDate);
    }
  }

  public formatDate(date) {
    const d = new Date(date);
    let month = '' + (d.getMonth() + 1);
    let day = '' + d.getDate();
    const year = d.getFullYear();

    if (month.length < 2) {month = '0' + month; }
    if (day.length < 2) {day = '0' + day; }

    return [year, month, day].join('-');
  }

  public suspendProject(project: Project) {
    project.endDate = this.formatDate(new Date());
    this.projectService.updateProject(project).then(data => {
      this.initialize();
    }).catch(error => { alert('Failed to update project!'); });
  }
}
