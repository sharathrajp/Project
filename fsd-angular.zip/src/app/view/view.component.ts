import { Component, OnInit } from '@angular/core';
import { Task } from '../dto/task.dto';
import { TaskService } from '../service/task.service';

import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {

  public taskList: any;
  public taskListCopy: any;
  public taskSearchField: string;

  constructor(private taskService: TaskService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit() {
    this.initialize();
  }

  private getTasks() {
    this.taskService.getTasks().then(tasks => {
      this.taskList = tasks;
      this.taskListCopy = JSON.parse(JSON.stringify(tasks));
    });
  }

  private initialize() {
    this.getTasks();
  }

  public searchTask() {
    this.taskList = this.taskListCopy.filter(task => {
      if (task.task.toLocaleLowerCase().search(this.taskSearchField.toLocaleLowerCase()) !== -1) {
        return true;
      }
      return false;
    });
  }

  public clearTaskSearch() {
    if (!this.taskSearchField) {
      this.taskList = JSON.parse(JSON.stringify(this.taskListCopy));

    }
  }

  public sortTasks(column: any, type: any) {
    this.taskList.sort((task1, task2) => {
      if (type === 'date') {
        return new Date(task1[column]).getTime() - new Date(task2[column]).getTime();
      } else if (type === 'number') {
        return Number(task1[column]) - Number(task2[column]);
      } else if (type === 'string') {
        return String(task1[column]).localeCompare(String(task2[column]));
      }
    });
  }

  public editTask(task: Task) {
    this.router.navigateByUrl('add?edit=true&taskId=' + task.taskId);
  }

  disableKill(start, end) {
    const startDate = new Date(start);
    const endDate = new Date(end);
    const today = new Date();
    today.setHours(0);
    today.setMinutes(0);
    today.setMilliseconds(0);
    startDate.setHours(0);
    startDate.setMinutes(0);
    startDate.setMilliseconds(0);
    endDate.setHours(0);
    endDate.setMinutes(0);
    endDate.setMilliseconds(0);
    if (this.compareDate(startDate, today) <= 0 && this.compareDate(endDate, today) === 1) {
      return false;
    }
    return true;
  }

  public compareDate(startDate: Date, endDate: Date) {
    console.log(startDate);
    console.log(endDate);
    console.log(startDate.getFullYear() + ' ' + startDate.getMonth() + ' ' + startDate.getDate());
    console.log(endDate.getFullYear() + ' ' + endDate.getMonth() + ' ' + endDate.getDate());
    if (startDate.getFullYear() > endDate.getFullYear()) {
      return 1;
    } else if (startDate.getFullYear() < endDate.getFullYear()) {
      return -1;
    } else {
      if (startDate.getMonth() > endDate.getMonth()) {
        return 1;
      } else if (startDate.getMonth() < endDate.getMonth()) {
        return -1;
      } else {
        if (startDate.getDay() > endDate.getDate()) {
          return 1;
        } else if (startDate.getDay() < endDate.getDate()) {
          return -1;
        } else {
          return 0;
        }
      }
    }
  }

  public endTask(task: Task) {
      task.endDate = this.formatDate(new Date());
      this.taskService.updateTask(task).then(data => {
        this.initialize();
      }).catch(error => {
        alert('Fail to update task!');
      });
  }

  public formatDate(date) {
    const d = new Date(date);
    let month = '' + (d.getMonth() + 1);
    let day = '' + d.getDate();
    const year = d.getFullYear();

    if (month.length < 2) {month = '0' + month; }
    if (day.length < 2) {day = '0' + day; }

    return [year, month, day].join('-');
  }
}
