package service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import dao.ParentTaskDAO;
import dao.ProjectDAO;
import dao.TaskDAO;
import dao.UsersDAO;
import model.ParentTask;
import model.Project;
import model.Task;
import model.Users;

@Component
public class TaskService {
	@Autowired
	private TaskDAO taskDAO;
	@Autowired
	private ParentTaskDAO parentTaskDAO;
	@Autowired
	private ProjectDAO projectDAO;
	@Autowired
	private UsersDAO usersDAO;

	public Task findTaskById(Long id) {
		if (taskDAO.existsById(id)) {
			return taskDAO.findById(id).get();
		}
		return null;
	}

	public List<Task> getAllTasks() {
		return taskDAO.findAll();
	}

	public Task getTasks(Long id) {
		return taskDAO.findById(id).get();
	}

	public Long saveTask(Task task) {
		ParentTask parentTask = task.getParentTask();
		Project project = task.getProject();
		Project savedProject = null;
		ParentTask savedParentTask = null;
		Task savedTask = null;
		try {
			if (parentTask != null) {
				savedParentTask = parentTaskDAO.save(parentTask);

			}
			if (project != null) {
				savedProject = projectDAO.findById(project.getProjectId()).get();
				task.setProject(savedProject);
			}
			try {
				savedTask = taskDAO.save(task);
			} catch (Exception e) {
				return new Long(-1);
			}
		} catch (Exception e) {
			if (savedParentTask != null) {
				parentTaskDAO.deleteById(savedParentTask.getParentId());
			}
			return new Long(-1);
		}
		return savedTask.getTaskId();
	}

	public boolean updateTask(Task task) {
		Task updatedTask = null;
		ParentTask parentTask = task.getParentTask();
		ParentTask updatedParentTask = null;
		Project project = task.getProject();
		Project updatedProject = null;
		try {
			updatedParentTask = parentTaskDAO.save(parentTask);
			task.setParentTask(updatedParentTask);
			updatedProject = projectDAO.findById(project.getProjectId()).get();
			task.setProject(updatedProject);
			try {
				updatedTask = taskDAO.save(task);
			} catch (Exception e) {
				return false;
			}
		} catch (Exception e) {
			return false;
		}
		return true;
	}

	public boolean deleteTask(Long id) {
		try {
			taskDAO.deleteById(id);
		} catch (Exception e) {
			return false;
		}
		return true;
	}

	public Long saveProject(Project project) {
		Project savedProject = null;
		try {
			savedProject = projectDAO.save(project);
		} catch (Exception e) {
			return new Long(-1);
		}
		return savedProject.getProjectId();
	}

	public boolean saveUser(Users user) {
		try {
			usersDAO.save(user);
		} catch (Exception e) {
			return false;
		}
		return true;
	}

	public boolean updateUser(Users user) {
		try {
			Users retrievedUser = usersDAO.findById(user.getUserId()).get();
			retrievedUser.setFirstName(user.getFirstName());
			retrievedUser.setLastName(user.getLastName());
			retrievedUser.setEmployeeId(user.getFirstName());
			usersDAO.save(retrievedUser);
		} catch (Exception e) {
			return false;
		}
		return true;
	}

	public boolean assignTaskToUser(Long userId, Long taskId) {
		try {
			Task task = taskDAO.findById(taskId).get();
			Users user = usersDAO.findById(userId).get();
			user.setTask(task);
			usersDAO.save(user);
		} catch (Exception e) {
			return false;
		}
		return true;
	}

	public boolean assignProjectToUser(Long userId, Long projectId) {
		try {
			Project project = projectDAO.findById(projectId).get();
			Users user = usersDAO.findById(userId).get();
			user.setProject(project);
			usersDAO.save(user);
		} catch (Exception e) {
			return false;
		}
		return true;
	}

	public List<Users> getUsers() {
		List<Users> userList = null;
		try {
			userList = usersDAO.findAll();
		} catch (Exception e) {
			return new ArrayList<Users>(0);
		}
		return userList;
	}
	
	public boolean deleteUser(Long userId) {
		try {
			usersDAO.deleteById(userId);
		} catch(Exception e) {
			return false;
		}
		return true;
	}
	
	public List<Project> getProjects() {
		List<Project> projectList = null;
		try {
			projectList = projectDAO.findAll();
		} catch (Exception e) {
			return new ArrayList<Project>(0);
		}
		return projectList;
	}
}
