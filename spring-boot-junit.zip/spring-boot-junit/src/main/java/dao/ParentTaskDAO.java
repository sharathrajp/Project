package dao;

import org.springframework.data.jpa.repository.JpaRepository;

import model.ParentTask;

public interface ParentTaskDAO extends JpaRepository<ParentTask, Long>{

}
