package dao;

import org.springframework.data.jpa.repository.JpaRepository;

import model.Task;

public interface TaskDAO extends JpaRepository<Task, Long>{
}
