package controller;

import static org.junit.Assert.*;

import org.junit.Test;

public class TaskControllerTest {
	TaskController instance=new TaskController();

	@Test
	public void test() {
		instance.getAllTasks();
	}

}
