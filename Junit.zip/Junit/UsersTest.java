package model;
import org.junit.Test;
public class UsersTest {
	
	Users instance = new Users();

	
	@Test
	public void test_getTaskID()
	{
		instance.getUserId();
	}
	
	@Test
	public void test_setTaskID()
	{
		instance.setUserId(1234567890L);
	}
	
	@Test
	public void test_getFirstName()
	{
		instance.getFirstName();
	}
	
	@Test
	public void test_setFirstName()
	{
		instance.setFirstName("test");
	}
	
	

	@Test
	public void test_getLastName() {
		instance.getLastName();
	}

	@Test
	public void test_setLastName() {
		instance.setLastName("raj");
	}
	
	@Test
	public void test_getEmpID() {
		instance.getEmployeeId();
	}

	@Test
	public void test_setEmpID() {
		instance.setEmployeeId("123");
	}

	@Test
	public void test_getProject() {
		instance.getProject();
	}

	@Test
	public void test_setProject() {
		instance.setProject(null);
	}

	@Test
	public void test_getTask() {
		instance.getTask();
	}

	@Test
	public void test_setTask() {
		instance.setTask(null);
	}


	
	
	
	
}
