package model;

import org.junit.Test;

public class ParentTaskTest {
	
	ParentTask instance=new ParentTask();
	
	@Test
	public void test_getparentID()
	{
		instance.getParentId();
	}
	
	@Test
	public void test_setparentID()
	{
		instance.setParentId(1234567890L);
	}
	
	@Test
	public void test_getparentTask()
	{
		instance.getParentTask();
	}
	
	@Test
	public void test_parentTask()
	{
		instance.setParentTask("test");
	}

}
