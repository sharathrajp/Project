package model;

import org.junit.Test;

public class ProjectTest {

	Project instance = new Project();

	@Test
	public void test_getProjectId() {
		instance.getProjectId();
	}

	@Test
	public void test_setProjectId() {
		instance.setProjectId(1234567890L);
	}

	@Test
	public void test_getProject() {
		instance.getProject();
	}

	@Test
	public void test_setProject() {
		instance.setProject("test");
	}

	@Test
	public void test_getPriority() {
		instance.getPriority();
	}

	@Test
	public void test_setPriority() {
		instance.setPriority(1234567890L);
	}

	@Test
	public void test_getstartdate() {
		instance.getStartDate();
	}

	@Test
	public void test_setstartdate() {
		instance.setStartDate(null);
	}
	
	@Test
	public void test_getenddate() {
		instance.getEndDate();
	}

	@Test
	public void test_setenddate() {
		instance.setEndDate(null);
	}

}
