package model;
import org.junit.Test;
public class TaskTest {
	Task instance=new Task();
	
	@Test
	public void test_getTaskID()
	{
		instance.getTaskId();
	}
	
	@Test
	public void test_setTaskID()
	{
		instance.setTaskId(1234567890L);
	}
	
	@Test
	public void test_getTask()
	{
		instance.getTask();
	}
	
	@Test
	public void test_setTask()
	{
		instance.setTask("test");
	}
	
	

	@Test
	public void test_getProject() {
		instance.getProject();
	}

	@Test
	public void test_setProject() {
		instance.setProject(null);
	}

	@Test
	public void test_getPriority() {
		instance.getPriority();
	}

	@Test
	public void test_setPriority() {
		instance.setPriority(1234567890L);
	}

	@Test
	public void test_getstartdate() {
		instance.getStartDate();
	}

	@Test
	public void test_setstartdate() {
		instance.setStartDate(null);
	}
	
	@Test
	public void test_getenddate() {
		instance.getEndDate();
	}

	@Test
	public void test_setenddate() {
		instance.setEndDate(null);
	}
	
	@Test
	public void test_getParentTask()
	{
		instance.getParentTask();
	}
	
	@Test
	public void test_setParentTask()
	{
		instance.setParentTask(null);
	}
	
	@Test
	public void test_getStatus()
	{
		instance.getStatus();
	}
	
	@Test
	public void test_setStatus()
	{
		instance.setStatus("pending");
	}
	
	

}
