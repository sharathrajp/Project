package controller;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;

import model.Task;
import service.TaskService;

public class TaskControllerTest {
	TaskController instance = new TaskController();
	@Autowired
	//private TaskService taskService;
	List<Task> arlist = new ArrayList<Task>();
	
	@Mock
	Task task=mock(Task.class);
	TaskService taskService=mock(TaskService.class);

	@Test
	public void test_getAllTasks() {
		// when(taskService.getAllTasks()).thenReturn(null);
		instance.getAllTasks();
	}

	@Test
	public void test_getAllTaskswithID() {
		instance.getAllTasks(1234567890L);
	}

	@Test
	public void test_deleteTasks() {
		instance.deleteTask(1234567890L);
	}

	@Test
	public void test_saveTasks() {
		instance.saveTask(null);
	}

	@Test
	public void test_updateTasks() {
		instance.updateTask(task);
	}

	@Test
	public void test_saveProject() {
		instance.saveProject(null);
	}

	@Test
	public void test_updateProject() {
		instance.updateProject(null);
	}

	@Test
	public void test_saveUser() {
		instance.saveUser(null);
	}

	@Test
	public void test_updateUser() {
		instance.updateUser(null);
	}

	@Test
	public void test_assignUserTask() {
		instance.assignUserTask(1234L, 5678L);
	}

	@Test
	public void test_assignUserProject() {
		instance.assignUserProject(1234L, 5678L);
	}

	@Test
	public void test_getUsers() {
		instance.getUsers();
	}

	@Test
	public void test_getProjects() {
		instance.getProjects();
	}

	@Test
	public void test_deleteUser() {
		instance.deleteUser(123456L);
	}

}
